


#include <map>

#include <iostream>
#include <fstream>
#include "json.hpp"
#include "httplib.h"
#include <iomanip>
#include <vector>
#include <utility>
#include <cstdlib>
#include <ctime>

using namespace std;
using namespace nlohmann;
using namespace httplib;

class Good
{
 public:
	string store;
	string name;
	float price;
	float weight;
	int total;
	int flag = 0;
	
	void input (json &j)
		{
			try
				{
				 store = j["store"];
				 name = j["name"];
				 price = j["price"];
				 weight = j["weight"];
				 total = j["total"];
				}
			catch(...)
				{
				 throw logic_error("wrong json");
				}
		}
	json pj()
		{
		 json print;
		 print["store"] = store;
		 print["name"] = name;
		 print["price"] = price;
		 print["weight"] = weight;
		 print["total"] = total;
		 
		 return print;	
		}
	void print()
		{
			cout<<pj()<<endl;
		//	cout<<store<<endl<<name<<endl<<price<<endl<<weight<<endl<<total<<endl;
		}	
			
};

class interface
{
 public:
	vector<Good> Goods;
	int add(json &a)
		{
			Good it;
			try
				{
					it.input(a);
					Goods.push_back(it);
					return 1;
				}
			catch(...)
				{
				 throw logic_error("wrong add");
				 return 0;
				}
		}
	void rand_add()
		{

				srand(time(0));
				Good tau;
				tau.price = static_cast <float> (rand()%200);
				tau.weight = 0 + rand()%15;
				tau.total = 0 + rand()%100;
				int ind1, ind2;
				ind1 = 1 + rand()%11;
				ind2 = 1 + rand()%11;
				string name, store;
				//cout<<"give name for good and name for store"<<endl;
				name = "name";
				store = "store";
				name = name + to_string(ind1);
				store = store + to_string(ind2);
				tau.name = name;
				tau.store = store;
				Goods.push_back(tau);
						
		}
	
	void del(int i)
		{
			if (i < (int) Goods.size() && i>=0)
				Goods.erase(Goods.begin()+i);
		}
	json printi()
		{
			
			json j;
			
			j["Array"] = json :: array();
	
			for (int i = 0; i < (int) Goods.size(); i++)
				j["Array"][i] = Goods[i].pj();
			return j;

		}
	void execute()
		{
			string name = "outfile.json";
			ofstream outfile(name);
			int n = 0, totalis = 0;
			json j;
			json jprint;
			string sname;
			//sname = name;
			//cout<<"enter good's name"<<endl;
			//printi(jprint);
			sname = Goods[0].name;	
					for (int i = 0; i < (int) Goods.size(); i++)
						{
							if (Goods[i].name == sname)
							{
								Goods[i].flag = 1;
								n = n + 1;
								totalis = totalis + Goods[i].total;
							}
						}
					totalis = totalis/n;
					for (int i = 0; i < (int) Goods.size(); i++)
						{
							if (Goods[i].flag == 1)
								Goods[i].total = totalis;
						}
					for (int i = 0; i < (int) Goods.size(); i++)
						Goods[i].flag = 1;	
				

			j["Array"] = json :: array();
	
			for (int i = 0; i < (int) Goods.size(); i++)
				j["Array"][i] = Goods[i].pj();
			outfile<<setw(4)<<j;
		}
	
};




std::map<httplib::Error, std::string> errors = {
  {httplib::Error::Success, "Success"},
  {httplib::Error::Unknown, "Unknown"},
  {httplib::Error::Connection, "Connection"},
  {httplib::Error::BindIPAddress, "BindIPAddress"},
  {httplib::Error::Read, "Read"},
  {httplib::Error::Write, "Write"},
  {httplib::Error::ExceedRedirectCount, "ExceedRedirectCount"},
  {httplib::Error::Canceled, "Canceled"},
  {httplib::Error::SSLConnection, "SSLConnection"},
  {httplib::Error::SSLLoadingCerts, "SSLLoadingCerts"},
  {httplib::Error::SSLServerVerification, "SSLServerVerification"},
  {httplib::Error::UnsupportedMultipartBoundaryChars, "UnsupportedMultipartBoundaryChars"}
};

