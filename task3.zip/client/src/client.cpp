#include "class.h"

int main()
{
 int command = 0;

 string menu = "0 - close program, 1 - add my data, 2 - add random data, 3 - execute, 4 - delete, 5 - print, 6 - get menu";
 cout<<menu<<endl;
 Client cli("localhost", 8080);
 while(1)
	{
		cout<<"get command"<<endl;
		if(!(cin>>command))
			{
				cout<<"wrong"<<endl;
				cin.clear();
				cin.ignore(1000,'\n');
			}
				
		if (command == 0)
			{
				auto res = cli.Post("/close");
				return 0;
			}
		
		if (command == 6)
			{
				cout<<menu<<endl;
			}
			
		if (command == 1)
			{
				if (auto res = cli.Post("/my_data"))
					{
						cout<<"check by print"<<endl;
					}
				else
					{
						auto err = res.error();
						cout << "Error: " <<errors.at(err)<<endl;
					}
			}
			
		if (command == 5)
			{
				if (auto res = cli.Post("/print"))
					{
						if (res->status == 500)
							{
								cout<<setw(4)<<json::parse(res->body)<<endl;
							}
					}
				else
					{
						auto err = res.error();
						cout<<"Error: "<< errors.at(err)<<endl;
					}
			}
			
		if (command == 2)
			{
				if (auto res = cli.Post("/add"))
					{
						cout<<"sucsess add"<<endl;
					}
				else
					{
						auto err = res.error();
						cout<<"Error :"<<errors.at(err)<<endl;
					}
			}

		if (command == 3)
			{
				if (auto res = cli.Post("/execute"))
					{
						cout<<"sucsess execute"<<endl;
					}
				else
					{
						auto err = res.error();
						cout<<"Error :"<<errors.at(err)<<endl;
					}
			}

		if (command == 4)
			{
					cout<<"send index's delete"<<endl;
					int indx;
					if (!(cin>>indx))
						{
							cout<<"error index"<<endl;
							cin.clear();
							cin.ignore(1000, '\n');
						}
					string index = to_string(indx);
				if (auto res = cli.Post("/delete", index, "plain/text"))
					{
						cout<<"sucsess delete"<<endl;
					}
				else
					{
						auto err = res.error();
						cout<<"Error :"<<errors.at(err)<<endl;
					}
			}


	}


}


























