#include "class.h"
int main()
{
 Server svr;
 interface face;
 ifstream file("data/one.json");
 json mass;
 json jsn;
 bool flag = true;

 svr.Post("/close",[&](const Request & req, Response &res)
 	{
		svr.stop();
	});
		
 svr.Post("/print", [&](const Request & req, Response & res)
	{
		json jprint;
		jprint = face.printi();
		res.status = 500;
		res.set_content(jprint.dump(), "application/json");
	});

 svr.Post("/add", [&](const Request &req, Response &res)
	{
		face.rand_add();
	});	

 svr.Post("/my_data", [&](const Request & req, Response & res)
	{
		if (flag)
			{
				file>>mass;
				flag = false;
			}
		while(face.add(mass["Array"][face.Goods.size()]));

	});	

 svr.Post("/execute", [&](const Request &req, Response &res)
	{
		face.execute();
		json jprint;
		jprint = face.printi();
		res.status = 500;
		res.set_content(jprint.dump(), "application/json");
	});	

 svr.Post("/delete", [&](const Request &req, Response &res)
	{
		string index = req.body;
		int indx = stoi(index);
		//cout<<indx<<endl;
		face.del(indx);
	});	



 svr.listen("localhost",8080);
 return 0;
}







